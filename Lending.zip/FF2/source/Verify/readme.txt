README: FFVerify

The FFVerify utility may be used to verify and repair FlashFiler 2
tables.

FFVerify was never officially released with FlashFiler 2 and should be
considered alpha quality.

FFVerify compiles with Delphi 5 and higher.
